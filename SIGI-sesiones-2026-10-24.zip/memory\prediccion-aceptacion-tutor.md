---
name: prediccion-aceptacion-tutor
description: Project to split the prediction panel into student (accept/send) and tutor (confirm received) versions; stage status, files and rules
metadata:
  type: project
---

Started 2026-10-20. Student accepts the prediction, can change/withdraw it until sending it definitively to the tutor; tutor only confirms "recibido". Deadline to accept ($fechaLimiteAceptacion in prediccion_comun.php). Notifications only inside SIGI (no email). User has CREATE TABLE rights. Both student and tutor log in with $cta (student = numero de control, tutor = tarjeta); programs keep a fixed test $cta with the dynamic session lines commented.

Stage 1 done and tested working in production 2026-10-21 (first failure was shared prediccion_*.php files not uploaded; student file now checks they exist): prediccionaceptaciones.sql (estatus A/E/R, snapshot of proposal "clave|tipo|creditos,..."), shared files prediccion_comun.php / prediccion_calculo.php / prediccion_estilos.php / prediccion_vista.php (extracted from panelprediccionmaterias.php, which stays untouched in production), and panelprediccionmateriasestudiante.php. Tutor comes from alumnosdatosacademicos.tutor (tarjeta) → usuarios.
Stage 2 done and tested working in production 2026-10-21 (prediccion_comun_etapa1.php kept as backup of stage-1 shared file, not used by any program): panelprediccionmateriastutor.php — list of tutorados (from alumnosdatosacademicos.tutor = $cta tarjeta) with status, filters, pending notice; only sent (E) or received (R) predictions can be opened; "Confirmar recibido" sets R. User decided: tutor sees only status for students who have not sent; no Situacion column in list (too slow). New pa* tutor functions added to prediccion_comun.php. Stage 3 (later): indicator in the SIGI menu / inicio.php (file not in local folder).

**Why:** user wants these as separate programs sharing code so one fix applies to both. **How to apply:** changes to the prediction logic now belong in the shared prediccion_*.php files; see [[sigi-php-conventions]].
