---
name: sigi-php-conventions
description: "How SIGI PHP programs are built and tested locally (base file to copy, tables, PHP binary)"
metadata:
  node_type: memory
  type: project
  originSessionId: 5f874601-cb51-4e6f-b067-a9e594ced98a
  modified: 2026-10-11T18:45:17.640Z
---

SIGI student programs (panelavanceacademico.php, panelprediccionmaterias.php) share one pattern: `$cta='0550'` hardcoded, include funciones_interfaz.php + bd.php, `head()/imagenEncabezado()/encabezado($cta)`, step 1 form asks only for número de control (8 chars), Spanish comments without accents, "Otro estudiante" + "REGRESAR" (inicio.php) buttons.

Key tables: alumnosdatosacademicos, alumnosdatospersonales, reticulas (clave, claveoficial, materia, creditos, semestre, modulo, estatus), cardex (oportunidad 1-2 ordinario, 3-4 repetición, 5-6 especial; aprobada >=70), Only in panelprediccionmaterias.php: cardex calificacion 0 counts as reprobada in the course its oportunidad marks (only blank = in progress). In course: oportunidad 1-2 with 0 → "Pasa a Curso Especial"; 3-4 with 0 → "Pasa a Baja por Curso Especial". User said (2026-10-10) NOT to apply this to other programs (e.g. panelavanceacademico.php keeps treating 0 as sin calificación). cargaacademica (materias en curso), reticulas_pre (prerrequisitos pre1..pre4).

Production server (sigi.orizaba.tecnm.mx) gave HTTP 500 on panelprediccionmaterias.php until the anonymous function in usort was replaced by a named one and new function names got a `pm` prefix (2026-10-09). Exact cause unconfirmed, but avoid closures/modern syntax and generic function names that may clash with funciones_interfaz.php; include a `$muestraErrores` switch for diagnosing 500s.

User saves adjustments in new numbered files (panelprediccionmaterias2.php, 3.php…) on purpose, to keep previous versions intact as a manual version history (no git here). Never modify an earlier version when told to save in a new file; keep editing the latest one until told to create the next. Every `<form action="...">` in the copy must point to the new filename, or the form posts back to the old version.

**How to apply:** funciones_interfaz.php is not in the local folder (server only), so lint with `/c/xampp/php/php.exe -l` and test logic by extracting functions into a scratch script.

As of 2026-10-19: panelprediccionmaterias.php is the current main version, tested working in production (copy of v5: reticula modal + fit-to-window, solo semestre inmediato siguiente, nc + "APELLIDOS NOMBRES" format, café for atrasadas). The original v1 was renamed to panelprediccionmaterias1.php; v2–v5 kept as history.
